
const form = document.getElementById("contact-form");

form.addEventListener("submit", (e) => {
    e.preventDefault();

    const myFormData = new FormData(e.target);

    const formDataObj = Object.fromEntries(myFormData.entries());

    formDataObj.favorite_pet = myFormData.getAll("favorite_pet");
    console.log(formDataObj);

    // output data
    const output = document.querySelector(".output-pre");
    output.innerText = JSON.stringify(formDataObj, null, 2);
});
